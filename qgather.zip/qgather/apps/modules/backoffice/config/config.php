<?php

use Phalcon\Config;

return new Config(
    [

    ]
);
