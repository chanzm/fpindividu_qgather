<?php

$namespace =  'Phalcon\Init\Dashboard\Controllers\Web';

$router->addGet('/register', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'User',
    'action' => 'register'
]);

//kalo store brati addpost
$router->addPost('/register', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'User',
    'action' => 'storeregister'
]);

$router->addGet('/dashboard', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'Dashboard',
    'action' => 'dashboard'
]);

$router->addGet('/dashboardadm', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'Dashboard',
    'action' => 'dashboardadmin'
]);

$router->addGet('/login', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'Admin',
    'action' => 'login'
]);

//kalo store brati addpost
$router->addPost('/login', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'Admin',
    'action' => 'storelogin'
]);

$router->addGet('/logout', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'Admin',
    'action' => 'logout'
]
);

$router->addGet('/dashboard/adm/listusr', [
    'namespace' => $namespace,
    'module' => 'dashboard',
    'controller' => 'Admin',
    'action' => 'listuser'
]
);
// $router->addGet('/add', [
//     'namespace' => $namespace,
//     'module' => 'dashboard',
//     'controller' => 'Dashboard',
//     'action' => 'adduser'
// ]
// );
// $router->addGet('/select', [
//     'namespace' => $namespace,
//     'module' => 'dashboard',
//     'controller' => 'User',
//     'action' => 'select'
// ]);
return $router;